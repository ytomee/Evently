"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useAuth } from "../context/AuthContext";

interface UserAccount {
  name: string;
  email: string;
  password: string;
  createdAt: string;
}

const STORAGE_KEY = "evently_users";

function saveUser(user: UserAccount): { ok: boolean; error?: string } {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const users: UserAccount[] = raw ? JSON.parse(raw) : [];

    const exists = users.some(
      (u) => u.email.toLowerCase() === user.email.toLowerCase()
    );
    if (exists) return { ok: false, error: "Este email já está registado." };

    users.push(user);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(users));
    return { ok: true };
  } catch {
    return { ok: false, error: "Erro ao guardar a conta. Tenta novamente." };
  }
}

export default function RegisterPage() {
  const { login } = useAuth();
  const router = useRouter();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!name.trim() || !email.trim() || !password.trim()) {
      setError("Todos os campos são obrigatórios.");
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError("Por favor, insere um email válido.");
      return;
    }

    if (password.length < 6) {
      setError("A palavra-passe deve ter pelo menos 6 caracteres.");
      return;
    }

    const result = saveUser({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      password,
      createdAt: new Date().toISOString(),
    });

    if (!result.ok) {
      setError(result.error ?? "Erro desconhecido.");
      return;
    }

    /* Auto-login after registration and redirect to dashboard */
    login(email.trim(), password);
    router.push("/dashboard");
  };

  return (
    <div className="flex items-center justify-center min-h-screen px-6">
      <div className="w-full max-w-md bg-white/[0.03] border border-soft/[0.12] rounded-2xl p-10 backdrop-blur-md">

        {/* Header */}
        <div className="mb-8">
          <Link
            href="/"
            className="text-xs font-medium tracking-[0.2em] uppercase text-muted hover:text-soft transition-colors duration-200 block mb-7"
          >
            evently
          </Link>
          <h1 className="text-2xl font-bold tracking-tight text-light mb-1">Criar conta</h1>
          <p className="text-sm text-muted">Começa a organizar os teus eventos.</p>
        </div>

        {/* Error */}
        {error && (
          <div className="mb-5 px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-sm">
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-5">

          <div className="flex flex-col gap-1.5">
            <label htmlFor="name" className="text-xs font-medium text-muted tracking-wide">
              Nome
            </label>
            <input
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="O teu nome"
              autoComplete="name"
              className="w-full px-4 py-3 bg-white/[0.04] border border-soft/[0.15] rounded-xl text-light text-sm placeholder:text-muted/50 outline-none focus:border-soft/50 transition-colors duration-200"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="email" className="text-xs font-medium text-muted tracking-wide">
              Email
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="email@exemplo.com"
              autoComplete="email"
              className="w-full px-4 py-3 bg-white/[0.04] border border-soft/[0.15] rounded-xl text-light text-sm placeholder:text-muted/50 outline-none focus:border-soft/50 transition-colors duration-200"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="password" className="text-xs font-medium text-muted tracking-wide">
              Palavra-passe
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Mínimo 6 caracteres"
              autoComplete="new-password"
              className="w-full px-4 py-3 bg-white/[0.04] border border-soft/[0.15] rounded-xl text-light text-sm placeholder:text-muted/50 outline-none focus:border-soft/50 transition-colors duration-200"
            />
          </div>

          <button
            id="register-btn"
            type="submit"
            className="mt-1 w-full py-3.5 bg-soft text-dark font-semibold text-sm rounded-full transition-all duration-200 hover:bg-light hover:-translate-y-px cursor-pointer"
          >
            Criar conta
          </button>
        </form>

        {/* Login link */}
        <p className="mt-6 text-center text-sm text-muted">
          Já tens conta?{" "}
          <Link href="/login" className="text-soft hover:text-light transition-colors duration-200">
            Iniciar sessão
          </Link>
        </p>
      </div>
    </div>
  );
}
